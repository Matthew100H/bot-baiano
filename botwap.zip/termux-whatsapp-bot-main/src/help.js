const help = (prefix) => {
	return `
「 *BOT_FIG_ZAP* 」

◪ *INFO*
  ❏ Prefixo: 「  ${prefix}  」
  ❏ Criador: WIZZY IRAKTÃ
◪ *SOBRE* WAP BOT 1.0
  │
  ├─ ❏ ${prefix}instagram : https://www.instagram.com/_wi22y/ <---> https://www.instagram.com/tio_russo12/

  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}grupo whatsapp : https://chat.whatsapp.com/CVChndtwcbQ1NqXuBkmHqN
  ├─ ❏ ${prefix} numero whatsapp : 86981140024
  └─ ❏ ${prefix}telegram : OFF

◪ *CRIADOR* 
  │
  ├─ ❏ ${prefix}sticker        ☆  converter imagem em figurinhas

  ├─ ❏ ${prefix}stickergif   ☆ converter videos curtos  ou gif em stickers

  ├─ ❏ ${prefix}toimg          ☆ converter adesivo em imagem 
  ├─ ❏ ${prefix}tomp3
  ├─ ❏ ${prefix}snowwrite
  ├─ ❏ ${prefix}3dtext
  ├─ ❏ ${prefix}neonlogo
  ├─ ❏ ${prefix}neonlogo2
  ├─ ❏ ${prefix}lionlogo
  ├─ ❏ ${prefix}jokerlogo
  ├─ ❏ ${prefix}shadow
  ├─ ❏ ${prefix}burnpaper
  ├─ ❏ ${prefix}coffee
  ├─ ❏ ${prefix}lovepaper
  ├─ ❏ ${prefix}woodblock
  ├─ ❏ ${prefix}qowheart
  ├─ ❏ ${prefix}mutgrass
  ├─ ❏ ${prefix}undergocean
  ├─ ❏ ${prefix}woodenboards
  ├─ ❏ ${prefix}wolfmetal
  ├─ ❏ ${prefix}metalictglow
  ├─ ❏ ${prefix}8bit
  ├─ ❏ ${prefix}harrypotter
  ├─ ❏ ${prefix}pubglogo
  └─ ❏ ${prefix}quotemaker

◪ *MEIOS DE COMUNICACAO*
  │
  ├─ ❏ ${prefix}trendtwit
  ├─ ❏ ${prefix}randomkpop
  └─ ❏ ${prefix}ytsearch    ☆ procurar videos no youtube 
  
◪ *EDUCACAO*
  │
  ├─ ❏ ${prefix}wiki
  ├─ ❏ ${prefix}wikien
  ├─ ❏ ${prefix}nulis
  ├─ ❏ ${prefix}quotes
  ├─ ❏ ${prefix}quotes2
  └─ ❏ ${prefix}artinama

◪ *MAGIC SHELL*
  │
  ├─ ❏ ${prefix}apakah
  ├─ ❏ ${prefix}kapankah
  ├─ ❏ ${prefix}rate
  └─ ❏ ${prefix}bisakah

◪ *DOWNLOADS*

  ├─ ❏ ${prefix}pinterest
  ├─ ❏ ${prefix}ytmp4  baixa videos youTube
  ├─ ❏ ${prefix}tiktok
  └─ ❏ ${prefix}joox

◪ *MEME*
  │
  ├─ ❏ ${prefix}meme
  └─ ❏ ${prefix}memeindo

◪ *GRUPO*
  │
  ├─ ❏ ${prefix}opengc
  ├─ ❏ ${prefix}closegc
  ├─ ❏ ${prefix}promote
  ├─ ❏ ${prefix}demote
  ├─ ❏ ${prefix}tagall
  ├─ ❏ ${prefix}tagall2
  ├─ ❏ ${prefix}tagall3
  ├─ ❏ ${prefix}tagall4
  ├─ ❏ ${prefix}tagall5
  ├─ ❏ ${prefix}add
  ├─ ❏ ${prefix}kick
  ├─ ❏ ${prefix}listadmins
  ├─ ❏ ${prefix}linkgroup
  ├─ ❏ ${prefix}leave
  ├─ ❏ ${prefix}welcome
  ├─ ❏ ${prefix}nsfw
  ├─ ❏ ${prefix}leveling
  ├─ ❏ ${prefix}level
  ├─ ❏ ${prefix}delete
  └─ ❏ ${prefix}ownergroup

◪ *SONS*
  │
  ├─ ❏ ${prefix}play  comando pra baixa musica .play nome da musica
  └─ ❏ ${prefix}tts
◪ *MUSICA*
  │
  ├─ ❏ ${prefix}lirik
  └─ ❏ ${prefix}chord
◪ *ISLAM*
  │
  └─ ❏ ${prefix}quran

◪ *STALK*
  │
  ├─ ❏ ${prefix}tiktokstalk
  └─ ❏ ${prefix}igstalk

◪ *WIBU*
  │
  ├─ ❏ ${prefix}neonime
  ├─ ❏ ${prefix}pokemon
  ├─ ❏ ${prefix}loli
  ├─ ❏ ${prefix}waifu
  ├─ ❏ ${prefix}randomanime
  ├─ ❏ ${prefix}husbu
  ├─ ❏ ${prefix}husbu2
  ├─ ❏ ${prefix}wait
  └─ ❏ ${prefix}nekonime

◪ *18+*  porno anime
  |
  ├─ ❏ ${prefix}randomhentai  ☆ porno hentai
  ├─ ❏ ${prefix}nsfwtrap           ☆ erro
  └─ ❏ ${prefix}nsfwneko         ☆ porno neko

◪ *DIVERSAO*
  │
  ├─ ❏ ${prefix}alay
  ├─ ❏ ${prefix}gantengcek
  ├─ ❏ ${prefix}watak
  ├─ ❏ ${prefix}hobby
  ├─ ❏ ${prefix}game
  ├─ ❏ ${prefix}bucin
  ├─ ❏ ${prefix}trust
  ├─ ❏ ${prefix}dare
  └─ ❏ ${prefix}simi

◪ *INFORMACOES*
  │
  ├─ ❏ ${prefix}bahasa  ☆ lista dos codigos dos paises
  ├─ ❏ ${prefix}kodenegara ☆ lista de todos paises do mundo 
  ├─ ❏ ${prefix}kbbi
  ├─ ❏ ${prefix}fakta
  ├─ ❏ ${prefix}infocuaca
  ├─ ❏ ${prefix}infogempa
  ├─ ❏ ${prefix}jadwaltvnow
  └─ ❏ ${prefix}covid

◪ *SOMENTE DONO DO BOT*
  │
  ├─ ❏ ${prefix}setprefix
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}bcgc     ☆ comando inativo
  ├─ ❏ ${prefix}clone    ☆ o bot usara a foto de perfil do contato marcado 
  └─ ❏ ${prefix}clearall ☆ limpar o chat 
  
◪ *OUTROS*
  │
  ├─ ❏ ${prefix}send      ☆ SPAM 
  ├─ ❏ ${prefix}wame    ☆  pegar o link do teu NUMERO
  ├─ ❏ ${prefix}virtex     ☆ comando pra enviar trava ( se usar o bot te bloquea )
  ├─ ❏ ${prefix}exe
  ├─ ❏ ${prefix}qrcode   ☆ QR code do bot
  ├─ ❏ ${prefix}afk
  ├─ ❏ ${prefix}timer
  ├─ ❏ ${prefix}fml
  └─ ❏ ${prefix}fml2

◪ *OWNER(2)_RUSSO*
`
}

exports.help = help
