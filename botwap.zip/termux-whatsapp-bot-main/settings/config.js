const config = {
        botName: 'BOT_NAME',
        ownerName: 'OWNER_NAME',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
